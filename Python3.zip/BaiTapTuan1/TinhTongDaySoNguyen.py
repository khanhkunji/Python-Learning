N = int(input("N = "))
sum = 0

for i in range(N + 1):
    sum += i

print(f"Tong day so nguyen tu 1 den {N} la: {sum}")