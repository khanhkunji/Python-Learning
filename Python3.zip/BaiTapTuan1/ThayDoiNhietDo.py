nhiet_do = float(input("Nhập nhiệt độ (°C): "))
don_vi = input("Nhập đơn vị muốn chuyển đổi (F/K): ").upper()

if don_vi == 'F':
    nhiet_do_f = (nhiet_do * 9/5) + 32
    print(f"Nhiệt độ sau khi chuyển đổi: {nhiet_do_f} °F")
elif don_vi == 'K':
    nhiet_do_k = nhiet_do + 273.15
    print(f"Nhiệt độ sau khi chuyển đổi: {nhiet_do_k} K")
else:
    print("Đơn vị không hợp lệ! Vui lòng nhập 'F' hoặc 'K'.")
