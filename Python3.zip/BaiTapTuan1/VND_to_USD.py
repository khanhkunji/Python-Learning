def to_usd(vnd, rate):
    return vnd / rate

def to_vnd(usd, rate):
    return usd * rate

def main():
    try:
        rate = float(input("Nhập tỉ giá (VND cho 1 USD), ví dụ 24000: ").strip())
        if rate <= 0:
            print("Tỉ giá phải lớn hơn 0.")
            return
    except ValueError:
        print("Tỉ giá không hợp lệ.")
        return

    choice = input("Chọn hướng đổi (1: VND→USD, 2: USD→VND): ").strip()
    if choice == "1":
        try:
            vnd = float(input("Nhập số VND: ").strip())
        except ValueError:
            print("Số tiền không hợp lệ.")
            return
        usd = to_usd(vnd, rate)
        print(f"{vnd:,.0f} VND = {usd:,.2f} USD (tỉ giá {rate:.2f} VND/USD)")
    elif choice == "2":
        try:
            usd = float(input("Nhập số USD: ").strip())
        except ValueError:
            print("Số tiền không hợp lệ.")
            return
        vnd = to_vnd(usd, rate)
        print(f"{usd:,.2f} USD = {vnd:,.0f} VND (tỉ giá {rate:.2f} VND/USD)")
    else:
        print("Lựa chọn không hợp lệ.")

if __name__ == "__main__":
    main()