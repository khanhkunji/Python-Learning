so_tien = int(input("Nhập số tiền thu nhập: "))

thue = 0 

if so_tien > 0:
    thue += so_tien * 0.05
if so_tien > 5000000:
    thue += (so_tien - 5000000) * 0.10
    so_tien = 5000000
if so_tien > 10000000:
    thue += (so_tien - 10000000) * 0.20
    so_tien = 10000000

print(f"Số tiền thuế phải nộp là: {thue}")

