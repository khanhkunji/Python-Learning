km = float(input("Nhập số km: "))
mile = km * 0.6213711922
print(f"{km} km = {mile} mile")
