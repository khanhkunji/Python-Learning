diem = float(input("Nhập điểm của bạn: "))

if diem < 0 or diem > 10:
    print("Điểm không hợp lệ")
elif diem >= 8.5 and diem <= 10:
    print("Xếp loại: A")
elif diem >= 7.0 and diem < 8.5:
    print("Xếp loại: B")
elif diem >= 5.5 and diem < 7.0:
    print("Xếp loại: C")
elif diem >= 4.0 and diem < 5.5:
    print("Xếp loại: D")
else:
    print("Xếp loại: F")