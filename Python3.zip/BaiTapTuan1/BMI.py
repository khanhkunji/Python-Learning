while True:
    try:
        h = float(input("Nhập chiều cao (m): "))
        w = float(input("Nhập cân nặng (kg): "))
        break
    except ValueError:
        print("Vui lòng nhập số hợp lệ")

# Tính BMI
bmi = w / (h * h)

if bmi < 18.5:
    print("Thiếu cân")
elif 18.5 <= bmi < 24.9:
    print("Bình thường")
elif 25 <= bmi < 29.9:
    print("Thừa cân")
else:
    print("Béo phì")
