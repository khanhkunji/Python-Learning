def cong(a,b):
    return a + b
def tru(a,b):
    return a - b
def nhan(a,b):
    return a * b
def chia(a,b):
    try:
        return a / b
    except ZeroDivisionError:
        return "Loi chia cho 0!!!"
def menu():
    print("""
    -MAY TINH DON GIAN-
        1. Cộng
        2. Trừ
        3. Nhân
        4. Chia
        5. Thoát/Tiếp tục
    """)

def nhap_so():
    a = int(input("Nhập số a: "))
    b = int(input("Nhập số b: "))
    return a,b

if __name__ == "__main__":
    menu()
    while True:
        chon = input("Chọn phép tính (1-5): ")
        if chon in ['1','2','3','4']:
            a,b = nhap_so()
            if chon == '1':
                print(f"Tong cua {a} + {b} = {cong(a,b)}")
            elif chon == '2':
                print(f"Hieu cua {a} - {b} = {tru(a,b)}")
            elif chon == '3':
                print(f"Tich cua {a} * {b} = {nhan(a,b)}")
            elif chon == '4':
                print(f"Thuong cua {a} / {b} = {chia(a,b)}")
        elif chon == '5':
            print("Thoát chương trình!!!")
            break
        else:
            print("Lựa chọn không hợp lệ, vui lòng chọn lại!!!")
   
    