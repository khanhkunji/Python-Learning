print("BANG CUU CHUONG 1-9")
for i in range(1,10):
    for j in range(1,11):
        print(f"{i} x {j} = {i*j}")
    print("------------")   
