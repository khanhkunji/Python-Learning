import random as rd

lan_doan = 7

number_bot = rd.randint(0, 101)

while lan_doan != 0:
    user = int(input("Ban doan so may? "))
    if user == number_bot:
        print("Chuc mung ban da doan dung!")
        break
    elif user < number_bot:
        print("So ban doan nho hon so may!")
    else:
        print("So ban doan lon hon so may!")
    lan_doan -= 1
    print(f"Ban con {lan_doan} lan doan!")

if lan_doan == 0:
    print(f"Ban da het lan doan! So may la {number_bot}")
