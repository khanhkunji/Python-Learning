def chuvi(pi,r):
    return 2*pi*r

def dientich(pi,r):
    return pi*r*r

if __name__ == "__main__":
    print("Chuong trinh tinh chu vi va dien tich hinh tron")
    pi = 3.14
    try:
        r = float(input("Nhap ban kinh: ").strip())
        if r < 0:
            print("Ban kinh phai lon hon hoac bang 0.")
            exit()
    except ValueError:
        print("Ban kinh khong hop le.")
        exit()

    cv = chuvi(pi,r)
    dt = dientich(pi,r)
    print(f"Chu vi hinh tron ban kinh {r} la: {cv:.2f} cm")
    print(f"Dien tich hinh tron ban kinh {r} la: {dt:.2f} cm^2")
