a = float(input("Nhập số a: "))
b = float(input("Nhập số b: "))
c = float(input("Nhập số c: "))

# so lon nhat 
max_value = a
if b > max_value:
    max_value = b
if c > max_value:
    max_value = c

print("Số lớn nhất là:", max_value)