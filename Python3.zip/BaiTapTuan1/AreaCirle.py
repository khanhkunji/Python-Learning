def area_cirle(radius):
    pi = 3.14
    area = pi * radius * radius
    return area

r = float(input("R =  "))
print(f"Diện tích hình tròn bán kính {r} là: {area_cirle(r)}")