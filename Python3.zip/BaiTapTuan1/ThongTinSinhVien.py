from datetime import date

def hoten():
    ten = input("Nhập họ tên: ")
    return (f"Họ tên: {ten}")

def nam_sinh():
    ns = int(input("Nhập năm sinh: "))
    tuoi = date.today().year - ns
    return (f"Năm sinh: {ns}, Tuổi: {tuoi}")

def diachi():
    diachi = input("Nhập địa chỉ: ")
    return f"Địa chỉ: {diachi}"

if __name__ == "__main__":
    ht = hoten()
    t = nam_sinh()
    dc = diachi()

    print("-THÔNG TIN SINH VIÊN-")
    print(ht)
    print(t)
    print(dc)
    
