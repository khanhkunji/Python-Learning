def minu_to_hms(phut):
    gio  = phut//60
    phut = phut % 60
    giay = phut * 60
    return gio, phut, giay

phut = int(input("Nhập số phút: "))
print(f"{phut} phút = {minu_to_hms(phut)[0]} giờ, {minu_to_hms(phut)[1]} phút, {minu_to_hms(phut)[2]} giây")
