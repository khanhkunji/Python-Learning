# Đọc file văn bản
# with open("D:\\Python\\data\\data.txt" , mode="r", encoding="utf-8") as f:
#     for l in f:
#         l = l.rstrip("\n")
#         print(l) 

# Ghi file văn bản
# with open("D:\\Python\\data\\data.txt" , mode="a", encoding="utf-8") as f:
#     f.write("\n")
#     f.write("Life is beautiful .")
#     f.write("\n")
#     f.write("I love Python .")

# with open("D:\\Python\\data\\data.txt" , mode="r", encoding="utf-8") as f:
#     for l in f:
#         l = l.rstrip("\n")
#         print(l)

#Ghi file JSON
# import json
# text = {
#     "name": "Khanh",
#     "age": 23,
#     "address": "Phu Yen",
#     "skill": [
#         "Python",
#         "Java",
#         "C++"
#     ]
# }
# with open("D:\\Python\\data\\import.json" , mode="w", encoding="utf-8") as f:
#     json.dump(text,f,ensure_ascii=False, indent=4)


# # Đọc file JSON
# with open("D:\\Python\\data\\import.json" , mode="r", encoding="utf-8") as f:
#     data = json.load(f)
#     print(data)

#CSV 
# import csv
# #Ghi file CSV
# rows = [{"id": 1, "name": "A"}, {"id": 2, "name": "B"}]
# with open("D:\\Python\\data\\dt.csv" , mode="w", encoding="utf-8", newline='') as f:
#     w = csv.DictWriter(f, fieldnames=["id", "name"])
#     w.writeheader()
#     w.writerows(rows)

# #Đọc file CSV
# with open("D:\\Python\\data\\dt.csv" , mode="r", encoding="utf-8") as f:
#     for row in csv.DictReader(f):
#         print(row["id"], row["name"])

#Pathlib
from pathlib import Path

p = Path("D://Python//data") / "data.txt"
if p.exists() and p.is_file():
    text = p.read_text(encoding="utf-8")
    (p.parent / "data_copy.txt").write_text(text, encoding="utf-8")
    print(text)
else:
    print("File không tồn tại hoặc không phải là file văn bản.")
