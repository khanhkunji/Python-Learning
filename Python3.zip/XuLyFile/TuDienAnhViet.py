from collections import Counter

def duong_dan():
    return "D:\\Python\\data\\data.txt"

def open_file(path):
    with open(path, mode="r", encoding="utf-8") as f:
        data = f.read();
    return data

def luu_file(path,tu,nghia):
    with open(path, mode="a", encoding="utf-8") as f:
        f.write(f"{tu}={nghia}\n")

def danh_sach_tu_dien():
    ds = open_file(path)
    return ds

def them_tu_dien():
    tu = input("Nhập từ:")
    nghia = input("Nhập nghĩa của từ:")
    return tu,nghia
    
def kiem_tra_trung(tu):
    


def menu():
    print("|=====TỪ ĐIỂN ANH VIỆT======|")
    print("|1. Xem từ                  |")
    print("|2. Thêm từ                 |")
    print("|3. Thêm nhiều từ           |")
    print("|4. Lưu từ điển vào file    |")
    print("|5. Mở file từ điển         |")
    print("|6. Thoát                   |")
    print("|===========================|")

if __name__ == "__main__":
    path = duong_dan()
    open_file(path)
    tu,nghia = them_tu_dien()
    
    luu_file(path,tu,nghia)
    open_file(path)

            
            
