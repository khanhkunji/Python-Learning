s = input("Nhap chuoi so nguyen cach nhau boi dau phay: ")

nums = list(map(int,filter(None,map(str.strip,s.split(','))))) # Loai bo khoang trang va chuyen sang kieu int
print(f'Chuoi sau khi map : {nums}')  # Output: [1, 2, 3, 4, 5]