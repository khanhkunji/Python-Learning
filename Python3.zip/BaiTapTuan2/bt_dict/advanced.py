from collections import Counter,defaultdict

sl = Counter("banana")

g = defaultdict(list)

g["u"].append(42)

print(sl)
print(g.keys())