def mean_ds(ds):
    return sum(ds) / len(ds)

def median_ds(ds):
    ds_sorted = sorted(ds)
    n = len(ds_sorted)
    mid = n // 2
    if n % 2 == 0:
        return (ds_sorted[mid - 1] + ds_sorted[mid]) / 2
    else:
        return ds_sorted[mid]

def mode_ds(ds):
    freq = {}
    for x in ds:
        if x in freq:
            freq[x] += 1
        else:
            freq[x] = 1
    max_count = max(freq.values())
    modes = [k for k, v in freq.items() if v == max_count]
    if len(modes) == len(freq):
        return None  # No mode
    return modes

def xoa_trung_giu_thu_tu(ds):
    saves = set() # luu cac phan tu da xet
    rs = [] # luu ket qua

    for i in ds:
        if i not in saves: # neu chua xet thi them vao ket qua
            rs.append(i) # them vao ket qua
            saves.add(i) # them vao danh sach da xet
    return rs
def tach_danh_sach_chan_le(ds):
    chan = []
    le = []
    for x in ds:
        if x % 2 == 0:
            chan.append(x)
        else:
            le.append(x)
    return chan, le

if __name__ == "__main__":
    n = int(input("Nhap n so diem: "))

    ds = []

    for i in range(n):
        x = float(input("Nhap diem thu {}: ".format(i + 1)))
        ds.append(x)

    #ds = [5,7.5,8,9]

    # print("Danh sach diem vua nhap: ", ds)
    # print("Diem trung binh: ", mean_ds(ds))
    # print("Diem trung vi: ", median_ds(ds))
    # print("Diem nhieu nhat: ", mode_ds(ds))

    print("Danh sach diem vua nhap: ", ds)
    # print("Danh sach diem sau khi xoa trung giu thu tu: ", xoa_trung_giu_thu_tu(ds))
    chan, le = tach_danh_sach_chan_le(ds)
    chan_sorted = sorted(chan)
    le_sorted = sorted(le)
    print("Danh sach diem chan: ", chan_sorted)
    print("Danh sach diem le: ", le_sorted)