ls = []
n = int(input("Nhap so luong phan tu: "))

[ls.append(int(input("Nhap phan tu thu {}: ".format(i + 1)))) for i in range(n)]

print("Danh sach vua nhap: ", ls)

print("Danh sach sau khi binh phuong so le:" ,[x**2 if x % 2 != 0 else x for x in ls])
