def khoi_tao_tu_dien():
    return {}  # Trả về một từ điển rỗng

def them_tu(tu_dien, tu, nghia):
    c = False
    for t in tu_dien.keys():
        if t.lower() == tu.lower():  # So sánh không phân biệt chữ hoa chữ thường
            c = True
            break
    if not c:
        tu_dien[tu] = nghia  # Thêm từ và nghĩa vào từ điển nếu từ chưa tồn tại
    return tu_dien


def xoa_tu(tu_dien, tu):
    if tu in tu_dien:
        del tu_dien[tu]  # Xóa từ khỏi từ điển nếu tồn tại
    return tu_dien

def tim_nghia(tu_dien, tu):
    for t, nghia in tu_dien.items():
        if t.lower() == tu.lower():  # So sánh không phân biệt chữ hoa chữ thường
            return nghia
    return "Không tìm thấy từ."  # Trả về thông báo nếu không tìm thấy từ

def hien_thi_tu_dien(tu_dien):
    for tu, nghia in tu_dien.items():
        print(f"{tu}: {nghia}")  # Hiển thị tất cả các từ và nghĩa trong từ điển

def cap_nhat_nghia(tu_dien, tu, nghia_moi):
    for t in tu_dien.keys():
        if t.lower() == tu.lower():  # So sánh không phân biệt chữ hoa chữ thường
            tu_dien[t] = nghia_moi  # Cập nhật nghĩa mới cho từ
            break
    return tu_dien

def dem_so_tu(tu_dien):
    return len(tu_dien)  # Trả về số lượng từ trong từ điển

def kiem_tra_tu(tu_dien, tu):
    for t in tu_dien.keys():
        if t.lower() == tu.lower():  # So sánh không phân biệt chữ hoa chữ thường
            return True
    return False

def menu():
    print("1. Khởi tạo từ điển")
    print("2. Thêm từ")
    print("3. Xóa từ")
    print("4. Tìm nghĩa của từ")
    print("5. Hiển thị từ điển")
    print("6. Cập nhật nghĩa của từ")
    print("7. Đếm số từ trong từ điển")
    print("8. Kiểm tra từ có tồn tại không")
    print("9. Thoát")

if __name__ == "__main__":
    menu()
    while True:
        luachon = input("Chọn một tùy chọn (1-9): ")
        if luachon == '1':
            tu_dien = khoi_tao_tu_dien()
            print("Đã khởi tạo từ điển.")
        elif luachon == '2':
            tu = input("Nhập từ: ")
            nghia = input("Nhập nghĩa: ")
            them_tu(tu_dien, tu, nghia)
            print(f"Đã thêm từ '{tu}' với nghĩa '{nghia}'.")
        elif luachon == '3':
            tu = input("Nhập từ cần xóa: ")
            xoa_tu(tu_dien, tu)
            print(f"Đã xóa từ '{tu}' nếu nó tồn tại.")
        elif luachon == '4':
            tu = input("Nhập từ cần tìm nghĩa: ")
            print(f"Nghĩa của từ '{tu}': {tim_nghia(tu_dien, tu)}")
        elif luachon == '5':
            print("Từ điển hiện tại:")
            print("=====================")
            hien_thi_tu_dien(tu_dien)
            print("=====================")
        elif luachon == '6':
            tu = input("Nhập từ cần cập nhật nghĩa: ")
            if kiem_tra_tu(tu_dien, tu) == True:
                nghia_moi = input("Nhập nghĩa mới: ")
                print(f"Đã cập nhật nghĩa của từ '{tu}' thành '{nghia_moi}'.")
                cap_nhat_nghia(tu_dien, tu, nghia_moi)
            else:
                print(f"Từ '{tu}' không tồn tại trong từ điển.") 
        elif luachon == '7':
            print(f"Số từ trong từ điển: {dem_so_tu(tu_dien)}")
        elif luachon == '8':
            tu = input("Nhập từ cần kiểm tra: ")
            if kiem_tra_tu(tu_dien, tu):
                print(f"Từ '{tu}' có tồn tại trong từ điển.")
            else:
                print(f"Từ '{tu}' không tồn tại trong từ điển.")
        elif luachon == '9':
            print("Thoát chương trình.")
            break
        else:
            print("Lựa chọn không hợp lệ. Vui lòng chọn lại.")