def xoay_trai(t):
    return t[1:] + t[:1] # Xoay trai    

def xoay_phai(t):
    return t[-1:] + t[:-1] # Xoay phai

def xoay_k_lan_trai(t, k):
    k = k % len(t)  # De phong truong hop k lon hon do dai tuple
    return t[k:] + t[:k]  # Xoay k lan

def xoay_k_lan_phai(t, k):
    k = k % len(t)  # De phong truong hop k lon hon do dai tuple
    return t[-k:] + t[:-k]  # Xoay k lan

if __name__ == "__main__":
    t = (1, 2, 3, 4, 5)
    print("Tuple ban dau:", t)
    
    t_trai = xoay_trai(t)
    print("Tuple sau khi xoay trai:", t_trai)
    
    t_phai = xoay_phai(t)
    print("Tuple sau khi xoay phai:", t_phai)

    k = 2
    t_k_lan_trai = xoay_k_lan_trai(t, k)
    print(f"Tuple sau khi xoay {k} lan trai:", t_k_lan_trai)

    t_k_lan_phai = xoay_k_lan_phai(t, k)
    print(f"Tuple sau khi xoay {k} lan phai:", t_k_lan_phai)