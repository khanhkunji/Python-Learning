# Tuple examples
empty_t = ()
one = (42,)
no_paren = 1,2,3
tupple_from_list = tuple([1,2,3])
print("Empty tuple : ",empty_t)
print("One element tuple : ",one)
print("No parenthesis tuple : ",no_paren)
print("Tuple from list : ",tupple_from_list)

#Unbacking
x,y,z = no_paren # x=1, y=2, z=3
print("Unpacking : ",x,y,z)

a, *rest = (1,2,3,4,5) # a=1, rest=[2,3,4,5]
print("Unpacking with * : ",a,rest) 

#Mutable inside tuple
tp = ([1,2],4)
print("Before modifying mutable inside tuple : ",tp)
tp[0].append(3) # List inside tuple is mutable
print("After modifying mutable inside tuple : ",tp)
