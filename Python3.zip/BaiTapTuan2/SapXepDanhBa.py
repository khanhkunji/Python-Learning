contacts = [("Khanh","Duong"),
            ("An","Nguyen"),
            ("Binh","Le"),]

sorted_contacts = sorted(contacts, key = lambda x: (x[0],x[1])) 

print(f"Sap xep danh ba theo ten: {sorted_contacts}")