def init_tuple():
    my_tuple = (1,2,2,3,4,5,5)
    return my_tuple

def slicing_tuple(t):
    return t[1:4:1] # Cat tu id 1 den 4 voi step la 1

def dem_phan_tu(t, value):
    x = t.count(value)
    y = t.index(value) if x > 0 else -1
    return x, y

# Tuple khong cho phep thay doi gia tri sau khi da khoi tao
# Tuy nhien, cac phan tu ben trong tuple neu la kieu du lieu co the thay doi (mutable) thi van co the thay doi
# Vi du: list, dict, set la cac kieu du lieu co the thay doi

def mutable_inside_tuple():
    tp = ([1,2], 4)
    print("Before modifying mutable inside tuple:", tp)
    tp[0].append(3) # List inside tuple is mutable
    print("After modifying mutable inside tuple:", tp)

def dem_so_lan(t):
    from collections import Counter
    count = Counter(t)
    return 

def dong_goi_zip(t1, t2):
    z = tuple(zip(t1, t2))
    return max(z, key = lambda x: x[1]) # Tim phan tu co gia tri lon nhat theo t2

def sap_xep_tuple(t):
    return sorted(t , key = lambda x: (x[0],x[1])) # Sap xep theo gia tri cua t2

def hoan_doi():
    a,b = 1,2 ; a,b = b,a 
    return a,b

def stats(a,b):
    return max(a,b), (a * b)

if __name__ == "__main__":
    t = init_tuple()
    print("Initialized tuple:", t)
    sliced = slicing_tuple(t)
    print("Sliced tuple (1:4:2):", sliced)
    count, index = dem_phan_tu(t, 2)
    print("Count and index of 2 in tuple:", count, index)
    mutable_inside_tuple() 
    dem_so_lan(t)
    print("Element counts in tuple:", dem_so_lan(t))

    t1 = ("Toan", "Van", "Anh")
    t2 = (9, 8, 10)
    zipped = dong_goi_zip(t1, t2)
    print("Zipped tuples:", zipped)

    data = [(2,'b'),(1,'c'),(1,'a')]
    sorted_t = sap_xep_tuple(data)
    print("Sorted zipped tuples:", sorted_t)

    a, b = hoan_doi()
    print("Swapped values:", a, b)

    maximum, quotient = stats(10, 3)
    print("Max and quotient:", maximum, quotient)