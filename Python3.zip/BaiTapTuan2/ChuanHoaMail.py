email = input("Nhập email: ")

print("Email chuẩn hóa:", email.strip().lower())