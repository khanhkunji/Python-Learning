#List 
ls = [1,2,3,4,5,6,7,8,9]

print(ls)

ls.append(10) # them phan tu vao cuoi danh sach
print(ls)

ls.extend([11,12,13]) # them nhieu phan tu vao cuoi danh sach
print(ls)

ls.insert(0,0) # them phan tu vao vi tri bat ki
print(ls)

ls.remove(5) # xoa phan tu co gia tri bang 5
print(ls)

print(ls.pop()) # xoa phan tu cuoi cung va tra ve phan tu do
print(ls)

print(ls.index(3)) # tra ve vi tri cua phan tu co gia tri bang 3

print(ls.count(3)) # dem so lan xuat hien cua phan tu co gia tri bang 3

a = ls.copy() # sao chep danh sach
print(a)

ls.clear() # xoa toan bo phan tu trong danh sach
print(ls)