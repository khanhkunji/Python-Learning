def menu():
    print("\n===UNIT CALCULATOR===")
    print("1).Convert C to F")
    print("2).Convert F to C")
    print("3).Convert Km to Mi")
    print("4).Convert Mi to Km")
    print("5).Convert Kg to Lb")
    print("6).Convert Lb to Kg")
    print("7).Exit")

def C_to_F(c):
    return c * (9/5) + 32

def F_to_C(f):
    return (f-32)*(5/9)

def km_to_mi(km):
    return km * 0.621371

def mi_to_km(mi):
    return mi * 1.60934

def kg_to_lb(kg):
    return kg * 2.20462

def lb_to_kg(lb):
    return lb * 0.453592

def Program():
    while True:
        menu()
        kq = 0
        inp = input("Chọn thao tác :")
        if inp == '1':
            C = float(input("Nhập độ C:"))
            kq = C_to_F(C)
            print(f"Độ C {C} sang độ F là {kq:.2f}")
        elif inp == '2':
            F = float(input("Nhập độ F:"))
            kq = F_to_C(F)
            print(f"Độ F {F} sang độ C là {kq:.2f}")
        elif inp == '3':
            Km = float(input("Nhập số Km:"))
            kq = km_to_mi(Km)
            print(f"Số KM là {Km} sang Mili là {kq:.2f}")
        elif inp == '4':
            mi = float(input("Nhập số mili:"))
            kq = mi_to_km(mi)
            print(f"Số Mili là {mi} sang KM là {kq:.2f}")
        elif inp == '5':
            kg = float(input("Nhập số Kg:"))
            kq = kg_to_lb(kg)
            print(f"Số Kg là {kg} sang Lb là {kq:.2f}")
        elif inp == '6':
            lb = float(input("Nhập số lb:"))
            kq = lb_to_kg(lb)
            print(f"Số Lb là {lb} sang Kg là {kq:.2f}")
        else:
            print("Hẹn gặp lại!!!")
            break

#Updating

import json 

def open_file(p):
    with open(p,"r",encoding="utf-8") as f:
        conv = json.load(f)
    return conv # Trả về danh sách các cụm công thức

def convert_file(ds,x,src,dst):
    k = f"{src}-{dst}"
    if k not in ds:
        raise ValueError(f"Chưa hỗ trợ {src}-{dst}")

    #Đã tìm thấy 
    a = ds[k]["a"]
    b = ds[k]["b"]

    return f"{a*x + b:.2f}"


if __name__ == "__main__":
    Program()
    # path = r"D:\Python\data\convert.json"
    # ds = open_file(path)
    # print(convert_file(ds,37,"c","f"))
    # print(convert_file(ds,37,"f","c"))
    # print(convert_file(ds,37,"km","mi"))
    # print(convert_file(ds,37,"mi","km"))
    # print(convert_file(ds,37,"kg","lb"))
    # print(convert_file(ds,37,"lb","kg"))
    # Có thể cập nhật thêm vài đơn vị đổi