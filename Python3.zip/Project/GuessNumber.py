import random as rd

def Display():
    print("------------------")
    print("GUESS NUMBER 2025")
    print("------------------")
    print("1. Play now")
    print("2. Exit game")
    print("==================")

def RandomNumber():
    return rd.randint(0,101) # Pham vi tu 1 den 100

def GamePlay():
    
    bot = RandomNumber() # Bot
    status = ""
    #Counting 
    cnt = 5
    while cnt > 0:
        user = int(input("Enter a number:"))
        if user == bot:
            print("You Win!")
            status = "WIN"
            break
        elif user > bot :
            print("Your number is larger than Bot!")
        else:
            print("Your number is smaller than Bot!")
        cnt -= 1

    if cnt == 0:
        print(f"You lose!!! The number is {bot}")
        status = "LOSE"

    return cnt,status,bot

def SaveHistoryPlayGame(cnt,status,bot):
    with open("D:\\Python\\data\\history_quess_game.txt" , mode = "a", encoding="utf-8") as f:
        f.writelines(f"Số của máy là {bot} - Số lần đoán còn lại là {cnt} - Trạng thái {status}\n")  

if __name__ == "__main__":
    Display()

    #Game
    while True:
        ch = input("Choose:")
        if ch == '1':
            cnt,status,bot = GamePlay()
            SaveHistoryPlayGame(cnt,status,bot)
        elif ch == '2':
            print("Goodbye, See you again!!!")
            break
        else:
            print("Your choose is invalid!!! Again!")
        
