def menu():    
    print("""
    -----------------
    |   TO DO LIST  |
    -----------------
    0.Create new(1) / Override file(2)
    1.Add a task
    2.Update a task
    3.Remove a task
    4.Display all
    5.Save File
    6.Open File
    7.Insert deadlines(datetime)
    8.Change status
    9. Show all deadline
    10.Find tasks (Incomplete|Completed)
    (For Exit , press C)
    ----------------""")

def create_list():
    d = [] # khoi tao 1 list rong
    return d

def override_list():
    import csv 
    from pathlib import Path
    p = r"D:\Python\data\to_do_list.csv"
    if not Path(p).exists():
        return create_list()
    with open(p, "r", encoding="utf-8") as f:
        return [r["Content"] for r in csv.DictReader(f)]

def counting_task(d):
    l = len(d)
    return l

def add_task(d):
    fl = True
    task = input("Enter a task:")
    for i in d:
        if task.lower() == str(i).lower():
            return False
        
    if fl == True:
        d.append(task.title())
        return True

def remove_task(d):
    id = int(input("Enter a number of task:"))
    l = counting_task(d)
    if  id-1 >= l:
        return False # Khong ton tai
    else:
        del d[id-1] 
        return True # Xoa thanh cong
    
def change_task(d):
    id = int(input("Enter a number of task:"))
    l = counting_task(d)
    if  id-1 >= l:
        return False # Khong ton tai
    else:
        change = input("Change content in task :")
        d[id-1] = change
        return True # Cap nhat thanh cong

def display_all(d):
    cnt = 1
    l = counting_task(d)
    id_content = {}
    if l == 0:
        print(f"List is empty!!!")
        return {}
    
    print("SHOW ALL TASKS")
    for t in d:
        print(f"   Task {cnt}")
        print(f"- {t}")
        print("="*20)
        F = f"Task_{cnt}"
        id_content[F] = t
        cnt += 1
    return id_content  

def research(d):
    cnt = 1
    l = counting_task(d)
    id_content = {}
    if l == 0:
        return {}
    for t in d:
        F = f"Task_{cnt}"
        id_content[F] = t
        cnt += 1
    return id_content  

import csv
def save_file(d, path = r"D:\Python\data\to_do_list.csv"):
    ct = research(d)  # ví dụ: {'Task_1': 'học Python', ...}
    if len(ct) == 0:
        return False
    # chuyển thành list các dict đúng fieldnames
    rows = [{"Task": k, "Content": v} for k, v in ct.items()]

    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=["Task", "Content"])
        w.writeheader()
        w.writerows(rows)
    return True

def open_file(path = r"D:\Python\data\to_do_list.csv"):
    # đọc kiểm tra
    with open(path, "r", encoding="utf-8") as f:
        for r in csv.DictReader(f):
            print(r["Task"], r["Content"])

#Update
def deadline(d):
    from datetime import datetime as dt
    l = counting_task(d)
    if l == 0:
        print("Not exists!!!") #Khong con task 
    else:
        cnt = 0
        ls = {}
        fm_dt = "%d/%m/%Y"
        for i in d:
            dmy = input(f"Enter date(dd/mm/yy) of task {cnt + 1} :")
            change_dt = dt.strptime(dmy,fm_dt)
            ls[i] = str(change_dt.date())
            cnt += 1
        print("Successed!!!")
        return ls 

def all_deadline(ls):
    #Print
    cnt = 0
    print("="*40)
    print("\t\tDEADLINE")
    print("="*40)
    for t,d in ls.items():
        print(f"[{cnt+1} - {t} - {d}]")
        cnt += 1
    print("="*40)

def status_task(d):
    l = counting_task(d)
    if l == 0:
        print("Not exist!!!")
    else:
        st = ["Incomplete","Completed"]
        task_st = {}
        cnt = 1
        print("===SET STATUS===")
        for i in d:
            print(f"-Task {cnt}")
            set_st = input("1.Incomplete\n2.Completed\nChoose:")
            if set_st == '1':
                task_st[cnt] = st[0]
            else:
                task_st[cnt] = st[1]
            cnt += 1
        
        print("==========STATUS==========")
        for i,v in task_st.items():
            print(f"(.)Task {i} - Status: {v}")
        print("==========================")
        return task_st

def find_task(d,task_st,status):
    l = counting_task(task_st)
    if l == 0:
        print("Empty!!!")
    else:
        chk = False
        for k,v in task_st.items():
            if status == v:
                print(f"- Task{k} : {d[k - 1]} is {v}")
                chk = True

        if chk == False:
            print("Not have!!!")
#Chuong trinh
if __name__ == "__main__":
    menu()
    checkInput = False
    check_r = False
    #Thao tac
    while True:
        choose = input("Choose:")
        if choose == '0':
            checkInput = True
            c = input("1.Create new - 2.Override File :")
            if c == '1':
                d = create_list()
            else:
                d = override_list()
            print("Init Successed!!!")
        elif choose == '1':
            if checkInput == True:
                val = add_task(d)
                if val == True:
                    print("Successed !!!")
                else:
                    print("Exist !!!")
            else:
                print("Must have a create list or override file!!!")
        elif choose == '2':
            if checkInput == True:
                val = change_task(d)
                if val == True:
                    print("Successed!!!")
                else:
                    print("Not change or not found!!!")
            else:
                print("Must have a create list or override file!!!")
        elif choose == '3':
            if checkInput == True:
                val = remove_task(d)
                if val == False:
                    print("Not exist!!!")
                else:
                    print("Removed!!!")
            else:
                print("Must have a create list or override file!!!")
        elif choose == '4':
            if checkInput == True:
                display_all(d)
            else:
                print("Must have a create list or override file!!!")
        elif choose == '5':
            if checkInput == True:
                fl = save_file(d)
                if fl == True:
                    print("Completed!!!")
                else:
                    print("Not saved!!!")
            else:
                print("Must have a create list or override file!!!")
        elif choose == '6':
            if checkInput == True:
                print("OPEN FILE IN CSV")
                open_file()
            else:
                print("Must have a create list or override file!!!")
        elif choose == '7':
            if checkInput == True:
                check_r = True
                print("===SET TIME FOR TASKS===")
                r = deadline(d)
            else:
                print("Must have a create list or override file!!!")
        elif choose == '8':
            if checkInput == True:
                t = status_task(d)
            else:
                print("Must have...")
        elif choose == '9':
            if checkInput == True and check_r == True:
                all_deadline(r)
            else:
                print("Must have...")
        elif choose == '10':
            if checkInput == True:
                tt = input("1. Find status - Incomplete\n2. Find status - Completed\nChoose:")
                if tt == '1':
                    inp = "Incomplete"
                else:
                    inp = "Completed"
                find_task(d,t,inp)
            else:
                print("Must have...")
        elif choose == 'C' or choose == 'c':
            print("Goodbye.See you again!!!")
            break