def init_file():
    path = r"D:\Python\data\money.csv"
    return path

def khoan_chi_tieu():
    from datetime import datetime

    so_tien = int(input("Khoản tiền đã chi(VNĐ):"))
    danh_muc = input("Danh mục chi tiêu\n1.Ăn uống\n2.Mua sắm\n3.Đầu tư\n4.Học phí\n5.Phí khác\n[.]Chọn:")
    
    dsdm = {'1':"Ăn uống",
            '2':"Mua sắm",
            '3':"Đầu tư",
            '4':"Học phí",
            '5':"Phí khác"}
    
    danh_muc = dsdm[danh_muc]
    
    ghi_chu = input("Ghi chú:").title().strip()

    #Date time 
    # dt = datetime.today() # Lấy giá trị ngày tháng hiện tại
    # fmd = dt.strftime("%d/%m/%Y")
    
    # Ngay thang - Nhap vao
    dmy = input("Nhập thời gian(dd/mm/yyyy):")
    dt = datetime.strptime(dmy,"%d/%m/%Y")
    f = {"danh_muc":danh_muc,"so_tien":so_tien,"ngay_thang_nam":str(dt.date()),"ghi_chu":ghi_chu}
    return f

# Updating
import csv
def w_file(p):
    f = khoan_chi_tieu()
    ls = []
    ls.append(f)
    with open(p , mode="w", encoding="utf-8", newline='') as f:
        w = csv.DictWriter(f, fieldnames=["danh_muc", "so_tien","ngay_thang_nam","ghi_chu"])
        w.writeheader()
        w.writerows(ls)

def o_file(p):
    cnt = 1
    with open(p , mode="r", encoding="utf-8") as f:
        for row in csv.DictReader(f):
            print(f"Bill({cnt})" , row["danh_muc"],row["so_tien"],row["ngay_thang_nam"],row["ghi_chu"])
            cnt += 1

if __name__ == "__main__":
    p = init_file()
    w_file(p)
    print("THÔNG TIN CHI TIÊU")
    o_file(p)